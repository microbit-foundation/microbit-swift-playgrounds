/*
 MIT License
 
 Copyright (c) 2018 micro:bit Educational Foundation
 Written by Gary J.H. Atkinson of Stinky Kitten Ltd.
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.
 */

import Foundation

/**
 Shows a number on the LED screen. It will slide left if it has more than one digit.
 - parameters:
    - _ A number as an Int or a Double, this cannot be omitted.
 */
public func showNumber(_ number: Int) {
    
    showString(String(number), handler: nil)
}

/**
 Shows a number on the LED screen. It will slide left if it has more than one digit.
 - parameters:
    - _ A number as an Int or a Double, this cannot be omitted.
 */
public func showNumber(_ number: Double) {
    
    showString(String(number), handler: nil)
}

/**
 Shows a number on the LED screen. It will slide left if it has more than one digit.
 - parameters:
    - _ A number as an Int or a Double, this cannot be omitted.
 */
public func showLeds(_ string: String) {
    
    MicrobitImage(string).showImage()
}

/**
 Shows the chosen icon on the LED screen.
 - parameters:
    - _ The icon name of the image you want to show. You can pick an icon image such as: .heart
 */
public func showIcon(_ iconName: MicrobitImage.IconName) {
    
    iconImage(iconName).showImage()
}

/**
 Shows a string on the LED screen. It will slide left if it is bigger than the screen.
 - parameters:
    - _ Text as a String, this cannot be omitted.
 */
public func showString(_ text: String, handler: DisplayTextHandler? = nil) {
    
    ContentMessenger.messenger.sendMessageOfType(.writeData,
                                                 forCharacteristicUUID: .ledTextUUID,
                                                 withData: text.microbitData,
                                                 handler: handler)
}

public func setScrollingDelay(_ delay: Double) {
    
    ContentMessenger.messenger.sendMessageOfType(.writeData,
                                                 forCharacteristicUUID: .ledScrollingDelayUUID,
                                                 withData: Data.littleEndianUInt16FromInt(Int(delay * 1_000)))
}

/**
 Shows the chosen arrow on the LED screen.
 - parameters:
    - _ The arrow name of the image you want to show. You can pick an icon image such as: .heart
 */
public func showArrow(_ arrowName: MicrobitImage.ArrowName) {
    
    arrowImage(arrowName).showImage()
}

/**
Turn off all the LED lights on the LED screen.
 */
public func clearScreen() {
    MicrobitImage().showImage()
}
