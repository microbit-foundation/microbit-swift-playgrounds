/*
MIT License

Copyright (c) 2018 micro:bit Educational Foundation
Written by Gary J.H. Atkinson of Stinky Kitten Ltd.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 */

import Foundation
import CoreMotion

public struct AccelerometerValues: CustomStringConvertible {
    
    var _x, _y, _z: Acceleration
    
    public init(x: Double, y: Double, z: Double) {
        self._x = Measurement(value: x, unit: UnitAcceleration.microbitGravity)
        self._y = Measurement(value: y, unit: UnitAcceleration.microbitGravity)
        self._z = Measurement(value: z, unit: UnitAcceleration.microbitGravity)
    }
    
    public init?(data: Data) {
        
        if let intX = data[0...1].integerFromLittleInt16,
            let intY = data[2...3].integerFromLittleInt16,
            let intZ = data[4...5].integerFromLittleInt16 {
            
            self.init(x: Double(intX), y: Double(intY), z: Double(intZ))
        } else {
            return nil
        }
    }
    
    public init(_ acceleration: CMAcceleration) {
        self._x = Measurement(value: acceleration.x, unit: UnitAcceleration.gravity).converted(to: .microbitGravity)
        self._y = Measurement(value: acceleration.y, unit: UnitAcceleration.gravity).converted(to: .microbitGravity)
        self._z = Measurement(value: acceleration.z, unit: UnitAcceleration.gravity).converted(to: .microbitGravity)
    }
    
    public var x: Double {
        get {
            return _x.value
        }
        set {
            _x.value = newValue
        }
    }
    
    public var y: Double {
        get {
            return _y.value
        }
        set {
            _y.value = newValue
        }
    }
    
    public var z: Double {
        get {
            return _z.value
        }
        set {
            _z.value = newValue
        }
    }
    
    public var strength: Double {
        get {
            return sqrt((_x.value * _x.value) + (_y.value * _y.value) + (_z.value * _z.value))
        }
    }
    
    public var measurements: (Acceleration, Acceleration, Acceleration) {
        get {
            return (x: _x, y: _y, z: _z)
        }
    }
    
    public var microbitData: Data {
        get {
            return Data(fromArray: [Int16(self.x).littleEndian, Int16(self.y).littleEndian, Int16(self.z).littleEndian])
        }
    }
    
    public var description: String {
        return "(x:\(_x), y:\(_y), z:\(_z))"
    }
}
