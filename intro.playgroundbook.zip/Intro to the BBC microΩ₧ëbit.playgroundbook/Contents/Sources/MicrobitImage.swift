/*
 MIT License
 
 Copyright (c) 2018 micro:bit Educational Foundation
 Written by Gary J.H. Atkinson of Stinky Kitten Ltd.
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.
 */

import UIKit

public enum LEDState: Int {
    case off = 0
    case on = 255
}

public class MicrobitImage: CustomStringConvertible, Equatable {
    
    var imageData = Data(count: 5)
    
    public init() {
    }
    
    public init(_ imageData: Data) {
        
        self.imageData = imageData
    }
    
    public init(_ imageText: String) {
        
        var x = 0, y = 0
        for char in imageText {
            
            switch (char) {
                
            case ".":
                x += 1
                
            case "\n":
                y += 1
                x = 0
                
            case " ":
                break
                
            default:
                self[x, y] = .on
                x += 1
            }
        }
    }
    
    public func plot(x: Int, y: Int) {
        self[x, y] = .on
    }
    
    public func unplot(x: Int, y: Int) {
        self[x, y] = .off
    }
    
    public func ledState(x: Int, y: Int) -> LEDState {
        return self[x, y]
    }
    
    public func setLedState(x: Int, y: Int, state: LEDState) {
        self[x, y] = state
    }
    
    func indexIsValid(x: Int, y: Int) -> Bool {
        return x >= 0 && x < 5 && y >= 0 && y < 5
    }
    
    public subscript(x: Int, y: Int) -> LEDState {
        
        get {
            assert(indexIsValid(x: x, y: y), "Index out of range")
            let ledY: UInt8 = self.imageData[y]
            let bitValue = UInt8(1 << (4 - x))
            return (ledY & bitValue) != 0 ? .on : .off
        }
        
        set {
            assert(indexIsValid(x: x, y: y), "Index out of range")
            var ledY: UInt8 = self.imageData[y]
            let bitValue = UInt8(1 << (4 - x))
            ledY = newValue == .on ? (ledY | bitValue) : (ledY & ~bitValue)
            self.imageData[y] = ledY
        }
    }
    
    public static func == (lhs: MicrobitImage, rhs: MicrobitImage) -> Bool {
        return lhs.imageData == rhs.imageData
    }
    
    public static prefix func ~ (image: MicrobitImage) -> MicrobitImage {
        
        var imageData = image.imageData
        for y in 0...4 {
            imageData[y] ^= 0b00011111
        }
        
        return MicrobitImage(imageData)
    }
    
    public static func | (image1: MicrobitImage, image2: MicrobitImage) -> MicrobitImage {
        
        var imageData = image1.imageData
        for y in 0...4 {
            imageData[y] |= image2.imageData[y]
        }
        
        return MicrobitImage(imageData)
    }
    
    public static func & (image1: MicrobitImage, image2: MicrobitImage) -> MicrobitImage {
        
        var imageData = image1.imageData
        for y in 0...4 {
            imageData[y] &= image2.imageData[y]
        }
        
        return MicrobitImage(imageData)
    }
    
    public static func + (image1: MicrobitImage, image2: MicrobitImage) -> MicrobitImage {
        return image1 | image2
    }
    
    public static func - (image1: MicrobitImage, image2: MicrobitImage) -> MicrobitImage {
        return image1 & ~image2
    }
    
    public var description: String {
        
        var stringDescription = ""
        
        for y in 0...4 {
            for x in 0...4 {
                if self.ledState(x: x, y: y) == .on {
                    stringDescription += "#"
                } else {
                    stringDescription += "."
                }
            }
            stringDescription += "\n"
        }
        return stringDescription
    }
    
    public func imageOffsetBy(dx: Int = 0, dy: Int = 0) -> MicrobitImage {
        
        if dx == 0 && dy == 0 {
            return self
        } else if abs(dx) > 4 || abs(dy) > 4 {
            return MicrobitImage()
        }
        
        var imageData = self.imageData
        // Do the x shifting
        if abs(dx) > 0 {
            for row in 0...4 {
                imageData[row] = dx.signum() == 1 ? imageData[row] << dx : imageData[row] >> abs(dx)
            }
        }
        // Do the y shifting
        if abs(dy) > 0 {
            for row in 0...4 {
                let sourceRow = row + dy
                switch sourceRow {
                case 0...4:
                    imageData[row] = imageData[row + dy]
                    
                default:
                    imageData[row] = 0
                }
            }
        }
        
        return MicrobitImage(imageData)
    }
    
    // MARK: - Convenience class constructors
}
