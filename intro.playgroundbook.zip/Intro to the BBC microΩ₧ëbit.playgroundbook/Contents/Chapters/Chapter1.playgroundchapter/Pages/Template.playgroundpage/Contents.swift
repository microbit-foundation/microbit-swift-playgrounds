//#-hidden-code
//
//  Contents.swift
//
//#-end-hidden-code
/*:#localized(key: "TemplateNarative")
 
 This page allows you to experiment with any Swift code and micro:bit API calls
 The documentation on each call is available by selecting the function and tapping 'Help'.
 */
import Foundation
