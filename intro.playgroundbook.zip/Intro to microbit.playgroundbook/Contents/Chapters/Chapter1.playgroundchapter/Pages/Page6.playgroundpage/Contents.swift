//#-hidden-code
//
//  Contents.swift
//
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 Welcome to the Swift Playground for exploring the micro:bit.
 
 Let's use the micro:bit to create a simple spirit level.
 
 1. steps:  Run the code below then click the A button on the micro:bit to see the heart image scrolled onto the screen.
 2. In the code, tap `.heart` to change the predefined image. Use the code completions to change the type of image.
 3. Re-run the code to see a different image.
 */
//#-hidden-code
import PlaygroundSupport

//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, ., showImage(), .duck, .sword, .chessboard, .target)

//#-end-hidden-code
//#-editable-code
clearScreen()
var lastX = 2
plot(x: lastX, y: 2)
onAcceleration({(accelerationValues) in
    let x = accelerationValues.x
    let xToPlot = -max(min(Int(x / 150), 2), -2) + 2
    if xToPlot != lastX {
        unplot(x: lastX, y: 2)
        plot(x: xToPlot, y: 2)
        lastX = xToPlot
    }
})

//#-end-editable-code
